LAB1 CMPUT 412:
Simon Fessehaye
Jonathon Machinski

All java files are found under the src folder. Report and README are with the same default directory.

To test (2j):
1.set motors to A and D port
2.connect to EV3
3.open test1.java
4.choose which function you want to test on the main function by commenting the rest
5.run test1.java on the EV3

To test (3):
1.set motors to A and D port
2.connect to EV3
3.open test1.java
4.choose reckoning_postion function from main with the command variable
5.run test1.java on the EV3

To test (5):(disable key repeats on your system)
1.set motors to A and C port
2.connect to EV3
3.run NXTtr.java on the EV3
4.run NXTremoteControl_TA.java as a java application

To test (6):(need two light sensors)
1.set motors to A and D port and sensors 2 and 4
2.connect to EV3
3.open lightbehavior.java
4.choose which function you want to test on the main function by commenting the rest
5.run lightbehavior.java on the EV3
